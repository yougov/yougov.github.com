import cherrypy
from sqlalchemy import *
from website import *
import sys
import os

PORT = 8000
if len(sys.argv) > 1:
	PORT = int(sys.argv[1])

db = create_engine('postgres', {'host':'localhost', 'database':'pycon'})

def get_photos():
	username, = db.execute('select username from users where id = %s', (USERID,)).fetchone()
	l = ["<h1>%s's Flickr Killr</h1>" % username]
	photos = db.execute('''
select p.id, p.filename, p.description
from users u join photos p on u.id = p.userid
where p.userid = %s''', (USERID,)).fetchall()
	l += ['''
<div><h3>%s</h3><img src='/photo/%s' /><p>%s</p></div>
''' % (p.filename, p.id, p.description) for p in photos]
	return ''.join(l)
	
class Photo(object):
	if 'CACHED' in os.environ:
		import cache_tool
		_cp_config = {'tools.memcache.on' : True}

	@cherrypy.expose
	def default(self, photoid):
		fn, photo = db.execute('select filename,photo from photos where id = %s', (photoid,)).fetchone()
		photo = str(photo)
		photo = photo.replace('\\000', chr(0)).replace('\\047',chr(39)).replace('\\134',chr(92))
		cherrypy.response.headers['Content-Type'] = 'image/%s' % fn.split('.')[-1]
		return photo

class Root(object):
	photo = Photo()
	@cherrypy.expose
	def index(self):
		return get_website(get_photos)

config = {
	'global': {
		'server.socket_port' : PORT,
	},
	'/static'  :  {
		'tools.staticdir.on' : True,
		'tools.staticdir.dir' : os.path.abspath('static'),
	},
}
if 'CACHED' in os.environ:
	config['/static']['tools.memcache.on'] = True
cherrypy.quickstart(Root(), config=config)
