import cherrypy
import memcache
import thread

mc_lock = thread.allocate_lock()
mc_conn = memcache.Client(['localhost:11211'])

def populate_memcached():
	mc_lock.acquire()
	try:
		resp = cherrypy.response
		req = cherrypy.request
		if resp.stream:
			return
		output = ''.join(resp.body)
		key = 'photosite-%s?%s' % (cherrypy.url(), req.query_string)
		mc_conn.set(key,output)
	finally:
		mc_lock.release()

cherrypy.tools.memcache = cherrypy.Tool('on_end_resource', populate_memcached)
