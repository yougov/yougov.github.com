#!/usr/bin/env python

import cgi
import sys
import psycopg2

f = cgi.FieldStorage()
conn = psycopg2.connect(database='pycon',host='localhost')
cur = conn.cursor()
cur.execute('select filename,photo from photos where id = %s', (f['photo'].value,))
fname, photo = cur.fetchone()
sys.stdout.write('Content-Type: image/%s\r\n\r\n' % fname.split('.')[-1])
photo = str(photo)
photo = photo.replace('\\000', chr(0)).replace('\\047',chr(39)).replace('\\134',chr(92))
sys.stdout.write(photo)
