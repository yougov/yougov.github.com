USERID = 1

def get_website(get_photos):
	return '%s%s%s' % (get_header(), get_body(get_photos), get_footer())

def get_header():
	return '''<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<link rel="stylesheet" type="text/css" href="/static/site.css"></link>
<meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
<title>Flickr Killr</title>
</head>'''

def get_body(get_photos):
	return '<body><div id="content">%s</div></body>' % get_photos()

def get_footer():
	return '</html>'
