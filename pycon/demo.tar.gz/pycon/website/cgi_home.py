#!/usr/bin/env python

import psycopg2
from website import *

def get_photos():
	conn = psycopg2.connect(database='pycon',host='localhost')
	cur = conn.cursor()
	cur.execute('select username from users where id = %s', (USERID,))
	username, = cur.fetchone()
	l = ["<h1>%s's Flickr Killr</h1>" % username]
	cur.execute('''
select p.id, p.filename, p.description
from users u join photos p on u.id = p.userid
where p.userid = %s''', (USERID,))
	l += ['''
<div><h3>%s</h3><img src='/cgi_photo.py?photo=%s' /><p>%s</p></div>
''' % (filename, id, description) for id, filename, description in cur.fetchall()]
	return ''.join(l)

webpage = get_website(get_photos)

print 'Content-Type: text/html\r\n\r\n'
print webpage
